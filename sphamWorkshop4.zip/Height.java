import java.util.Scanner;

public class Height{


public static void main(String[] args)
{

   int maleChildHeight = 0;
   int maleChildFeet = 0;
   int maleChildInch = 0;
   
   int femaleChildHeight = 0;
   String gender1 = "f";
   int femaleChildFeet = 0;
   int femaleChildInch = 0;
   
   System.out.println("Enter the gender of your future child. Use F for female, M for male.");
   Scanner scnr = new Scanner(System.in);
   
   String gender = scnr.next();
   
   System.out.println("Enter the height in feet then the height in inches of the mom with a space between.");
   int mFeet = scnr.nextInt(); 
   int mInch = scnr.nextInt();   
   
// Converting mom's feet to inches

   int feetToInch = mFeet * 12; 
   int mTotalHeight = feetToInch + mInch;
   
   
   System.out.println("Enter the height in feet then the height in inches of the dad with a space between.");
   int dFeet = scnr.nextInt();
   int dInch = scnr.nextInt();
   
// Converting dad's feet to inches
   
   int feetToInch2 = dFeet * 12;
   int dTotalHeight = feetToInch2 + dInch;
   
   
   // Determining child height
   
   if (gender.equalsIgnoreCase(gender1))
   {
      femaleChildHeight =(int)((dTotalHeight * (13.0/12.0)) + mTotalHeight)/2;
      femaleChildFeet = femaleChildHeight / 12;
      femaleChildInch = femaleChildHeight % 12;
      System.out.println("The estimated child height is " + femaleChildFeet + "' " + femaleChildInch + "\"");
   }
   
   else 
   {
      maleChildHeight =(int)((mTotalHeight * (13.0/12.0)) + dTotalHeight)/2;
      maleChildFeet = maleChildHeight / 12;
      maleChildInch = maleChildHeight % 12;
      System.out.println("The estimated child height is " + maleChildFeet + "' " + maleChildInch + "\"");

   }
   
}

}