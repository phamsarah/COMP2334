
public class Encryption {
	
	private int key; 
	private String encryptedPassword;
	
	
	/**
	 Default Constructor
	 */

	
	public Encryption() {
		key = 1;
		encryptedPassword = "";

	}
	
	/**
	 Constructs a Encryption with this() to set private String encryptedPassword with the default constructor and 
	 equals key with keyNum parameter value. 
	 @param keyNum the user key
	 @param Pass the user password 
	 
	 */
	public Encryption(int keyNum, String Pass) {
		this();
		key = keyNum;
		encrypt(Pass);
	}
	
	/**
	 	This method encrypts any given password and sets the instance variable encryptedPassword to the
	 	new encrypted password
	 	
	 	@param clearPass is the user input password
	 	@return no return since the method is void
	 	
	 */
	
	private void encrypt(String clearPass){
		for(int i = 0; i < clearPass.length(); i++) {
			int ascii = clearPass.charAt(i);
			int shift = ascii + this.key; 
			
			if (shift > 122)
				shift = 32 + (this.key - (122 - ascii));
		
			char encryptedCharacter = (char)(shift);
		
			this.encryptedPassword = this.encryptedPassword.concat(Character.toString(encryptedCharacter));
		
		}}
	
	/**
	 	This method will compare two passwords. It compares by
	 	encrypting the given password to the instance variable encryptedPassword given by the
	 	method getEncryptedPassword()
	 	
	 * @param clearPass
	 * @return returns true or false
	 
	 */
	
	public boolean isValidPassword(String clearPass) {
		
		String encryptedPass2 = "";
		
		for(int i = 0; i < clearPass.length() ; i++) {
			
			int ascii = clearPass.charAt(i);
			int shift = ascii + key; 
			
			if (shift > 122)
				shift = 32 + (key - (122 - ascii));
		
			char encryptedCharacter = (char)(shift);
			
			encryptedPass2 += encryptedCharacter;

		}

		if(encryptedPass2.equals(getEncryptedPassword()) == true)
		 return true;
		else 
		 return false;

	}
	
	/**
	 * This method retrieves the private instance variable
	 * @return returns the instance variable encryptedPassword
	 */
	
	public String getEncryptedPassword() {
		return encryptedPassword;
	}
	
	/**
	 This method will set the given key to the instance variable key and run encrypt to set the instance
	 variable encryptedPassword by running method encrypt()
	 * @param keyNum is the user key
	 * @param clearPass is the user password
	 */
	
	public void setPassword(int keyNum, String clearPass){
		this.key = keyNum; 
		encrypt(clearPass);
	}
	
	/**
	 * This method will retrieve the private instance variable key
	 * @return returns the instance variable key
	 */
	
	public int getKey() {
		return key; 
	}
	
	/**
	 * This method will use getEncryptedPassword() and getKey() to return an output
	 * @return returns a string output of the user's encrypted password and key they used
	 */
	
	public String toString() {
		
		return ("The encrypted password is " + getEncryptedPassword() + ". The key used to generate this password is " + getKey() + ".");
	}
	
}  


