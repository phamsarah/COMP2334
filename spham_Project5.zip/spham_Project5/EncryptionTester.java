/**
 EncryptionTester.java is the main program that asks the user input and uses
 Encryption.java to calculate and store the input. 
 
 @author Sarah Pham
 @version 1.0
 
 COP2253 	Project #: 5
 File Name: EncryptionTester.java
 
 */
import java.util.Scanner;

public class EncryptionTester {
	
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		String answer;
	
	do {
		
		System.out.println("Please enter a password: ");
		String userPass = scnr.next();
		
		while(userPass.length() < 8)
		{
			System.out.print("The password must be at least 8 characters long, your password is only " + userPass.length() + " characters long. ");
			System.out.println("Please enter another password: ");
			
			userPass = scnr.next();
		}
		
		System.out.println("Please enter a whole number between 1 and 10 (Inclusive); for the encryption key: ");
		int keyNumber = scnr.nextInt();
		
		while(keyNumber < 1 || keyNumber > 10) {
			System.out.println("The key must be between 1 and 10, you entered: " + keyNumber);
			System.out.println("Please enter another whole number between 1 and 10 (Inclusive): ");
			
			keyNumber = scnr.nextInt();
		}
		
		Encryption unencryptedPass = new Encryption();
		Encryption unencryptedPass2 = new Encryption(keyNumber, userPass);
		
		System.out.println(unencryptedPass2.toString());
		System.out.println("");
		
		// Testing the encrypt method
		
		System.out.println("Now testing the encryption, please enter your password: ");
		userPass = scnr.next();
		boolean valid = unencryptedPass2.isValidPassword(userPass);
		
		if(valid == true)
			System.out.println("Password is valid");
		else
			System.out.println("Password is not valid");
		
		System.out.println("");
		
		System.out.println("Now testing setPassword, getKey, and getEncryptedPassword: ");
		unencryptedPass.setPassword(keyNumber, userPass);
		System.out.println("Key: " + unencryptedPass.getKey());
		System.out.println("Encrypted Password: " + unencryptedPass.getEncryptedPassword());
		System.out.println("");
		
		System.out.println("Would you like to encrypt another password? If so type Y, hit any other key to quit: ");
		answer = scnr.next();
		
	
	  }while(answer.equalsIgnoreCase("y"));
}
}


