/**
This program calculates the cost
monthly for broadband service from CrookedTalk Inc.
depending on the user's plan and the
amount of data they used that month. 

@author Sarah Pham
@version 1.0

COP2253    Project 4
File Name: serviceCost.java
*/
package serviceCost;
import java.util.Scanner; 

public class serviceCost {

	public static boolean isValidPlan(String input) {
		
		boolean valid; 
		
		if(input.equalsIgnoreCase("A") || input.equalsIgnoreCase("B") || input.equalsIgnoreCase("C"))
			return valid = true; 
		else
			return valid = false;
		
	}
	
	public static double calculateMonthlyCost(String plan, int data) {
		
		double monthlyCost;
		int leftoverData = 0;                     // leftoverData is the data that the user went over in the plan
		
		if(plan.equalsIgnoreCase("A"))           // Implements data into Plan A Cost
		{
			if (data > 2)
				leftoverData = 5 * (data - 2); 

			monthlyCost = 24.95 + (double) leftoverData; 
			return monthlyCost; 
		}
		
		else if(plan.equalsIgnoreCase("B"))     // Impletements data into Plan B Cost 
		{
			if(data > 10)
				leftoverData = 5 * (data - 10);
			
			monthlyCost = 44.95 + (double) leftoverData; 
			return monthlyCost; 
		}
		
		else                                  // No other plan except C, so it is in an "else" statement - unlimited data so no calculations involved
		return monthlyCost = 75.95;  
	
		
	}
	
	
	public static void main(String[] args)
	{
		Scanner scnr = new Scanner(System.in);
		System.out.println("Enter the plan you are using: A, B, or C? ");
		String plan = scnr.next();
		
		boolean validOrNot = isValidPlan(plan);               // Checks if plan is valid 
	
			while(validOrNot == false) // Reprompts if the plan is invalid
			{
				System.out.println("Invalid, please enter plan you are using: A, B, or C? ");
				plan = scnr.next();
				validOrNot = isValidPlan(plan);   // Recalls for isValidPlan
			}
		
		System.out.println("Please enter the amount of data used in GB this month (1-1000 inclusive) : ");
		int dataUsed = scnr.nextInt();
		
			while(dataUsed < 1 || dataUsed > 1000)   // Checks for validity of data used - keeps looping and checks validity
			{
				System.out.println("Invalid, please enter amount of data used in GB this month (1-1000 inclusive) : ");
				dataUsed = scnr.nextInt();
			}

		double monthlyCost = calculateMonthlyCost(plan, dataUsed);  // Calls for calculateMonthlyCost 
		
		System.out.printf("Current Monthly Cost: $%.2f", monthlyCost);   // Nicely outputs monthly cost to the tenth place
		
	}
	
	
}
