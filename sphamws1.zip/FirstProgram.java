
public class FirstProgram
{
   public static void main(String[] args)
   {
      System.out.println("Hello Sarah.");
      System.out.println("Welcome to Java.");
   
      System.out.println("Let's demonstrate a simple calculation.");
      int answer;
      
      System.out.println("20 / 5 = " + 20/5);
      double d = 4.54;
      int a = 0;
   
      a--; // a = a - 1;
      System.out.println("b is " + a);
      a = (int)d + a;
      //answer = 4/0;
      final double INTRATE = 0.75;
      
      answer = 2 + 3;
      System.out.println("10 minus 2 is " + answer);
      
   }
}
