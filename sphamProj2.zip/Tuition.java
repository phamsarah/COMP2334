/**
This program calculates the cost of student
tuition 
Formula is costPerCourse * numberOfCourses


@author Sarah Pham
@version 1.0

COP2253    Project 2
File Name: Tuition.java
*/
import java.util.Scanner;

public class Tuition
{
	public static void main(String[] args) {
	    
	    int numberOfCourses = 0;
	    double costPerCourse = 0;
	    double Tuition1 = 0;
	    
	    int numberOfCourses2 = 0;
	    double costPerCourse2 = 0;
	    double Tuition2 = 0;
	    
		System.out.println("Enter info for first student:");
		System.out.print("First Name: ");
		
		Scanner scnr = new Scanner(System.in);
		
		String firstName = scnr.nextLine();
		
		// this part of the program converts the names into proper form
		firstName = firstName.toLowerCase();
		String firstLetter = firstName.substring(0,1);
		firstLetter = firstLetter.toUpperCase();
		firstName = firstLetter + firstName.substring(1);
		System.out.println(firstName);
		
		System.out.print("\n");
		System.out.print("Number of courses: ");
		numberOfCourses = scnr.nextInt();
		
		System.out.print("\n");
		System.out.print("Cost per course: ");
		costPerCourse = scnr.nextDouble();
		
		Tuition1 = costPerCourse * numberOfCourses; 
		
		
		// ----------- Second Student Input -------- 
		
		System.out.println("\n Enter info for second student:");
		System.out.print("Name: ");		
		
		String firstName2 = scnr.next();
		
		firstName2 = firstName2.toLowerCase();
		String firstLetter2 = firstName2.substring(0,1);
		firstLetter2 = firstLetter2.toUpperCase();
		firstName2 = firstLetter2 + firstName2.substring(1);
		System.out.println(firstName2);
		
		System.out.print("\n");
		System.out.print("Number of courses: ");
		numberOfCourses2 = scnr.nextInt();
		
		System.out.print("\n");
		System.out.print("Cost per course: ");
		costPerCourse2 = scnr.nextDouble();
		
		Tuition2 = costPerCourse2 * numberOfCourses2;		
		
		System.out.print("\n");
		
		//------- table output -------
		
		System.out.println("-------------------------------------------");
		System.out.printf("|%-10s| %-7s | %-6s | %-7s |%n", "Name","Courses","Cost", "Tuition");
		System.out.println("-------------------------------------------");
		System.out.printf("|%-10s| %7d | %6.2f |  %7.2f|%n", firstName, numberOfCourses , costPerCourse , Tuition1 );
		System.out.printf("|%-10s| %7d | %6.2f |  %7.2f|%n", firstName2, numberOfCourses2, costPerCourse2, Tuition2); 
		System.out.println("-------------------------------------------");
		
		
	
	}
}

