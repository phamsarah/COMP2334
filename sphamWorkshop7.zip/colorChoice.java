/**
This program has the user guess the color the program
has randomly selected 10 times and counts each time
the user guesses right.

@author Sarah Pham
@version 1.0

COP2253    Workshop 7
File Name: colorChoice.java
*/
package colorChoice;
import java.util.Scanner;
import java.util.Random;

public class colorChoice {

	public static String computerChoice(){   // This method call makes the program choose a random color based on number
		Random random = new Random();
		int randomNumber = random.nextInt(4);
		String cChoice = "";

		switch(randomNumber)
		{
			case 0:
			{
				cChoice = "Red";
				break;
			}

			case 1:
			{
				cChoice = "Green";
				break;
			}

			case 2:
			{
				cChoice = "Blue";
				break;
			}

			case 3:
			{
				cChoice = "Orange";
				break;
			}

			case 4:
			{
				cChoice = "Yellow";
				break;
			}

			default:
				return cChoice;
		}

		return cChoice;
	}

	public static String userChoice(){   // This method call gets user input and loops around until the input is valid

		System.out.println("I'm thinking of a color.");
		System.out.println("Is it red, green, blue, orange, or yellow?: ");

		Scanner scnr = new Scanner(System.in);
		String aChoice = scnr.next();
		boolean validChoice;

		do
		{
			validChoice = isValidChoice(aChoice);

			if(validChoice == true)
				break;
			else if (validChoice == false)
			{
				System.out.println("Invalid choice");
				System.out.println("I'm thinking of a color. ");
				System.out.println("Is it red, green, blue, orange, or yellow?: ");
				aChoice = scnr.next();
			}
		}while(validChoice == false);

		return aChoice;

	}
	public static boolean isValidChoice(String aChoice){ // This method call checks if the user input is valid to the colors in the program

		boolean validChoice;

		if(aChoice.equalsIgnoreCase("Red"))
			validChoice = true;
		else if(aChoice.equalsIgnoreCase("Green"))
			validChoice = true;
		else if(aChoice.equalsIgnoreCase("Blue"))
			validChoice = true;
		else if(aChoice.equalsIgnoreCase("Orange"))
			validChoice = true;
		else if(aChoice.equalsIgnoreCase("Yellow"))
			validChoice = true;
		else
			validChoice = false;


		return validChoice;
	}

		public static void main(String[] args){

			int correctCount = 0;
			System.out.println("This program will run 10 times");

			for(int i = 1; i <= 10; i++)    // Since workshop 7 instructions says to run the program 10 times, it is in a for-loop
			{

				String compChoice = computerChoice();
				String getInput = userChoice();/**
This program has the user guess the color the program
has randomly selected 10 times and counts each time
the user guesses right.

@author Sarah Pham
@version 1.0

COP2253    Workshop 7
File Name: colorChoice.java
*/
package colorChoice;
import java.util.Scanner;
import java.util.Random;

public class colorChoice {

	public static String computerChoice(){   // This method call makes the program choose a random color based on number
		Random random = new Random();
		int randomNumber = random.nextInt(4);
		String cChoice = "";

		switch(randomNumber)
		{
			case 0:
			{
				cChoice = "Red";
				break;
			}

			case 1:
			{
				cChoice = "Green";
				break;
			}

			case 2:
			{
				cChoice = "Blue";
				break;
			}

			case 3:
			{
				cChoice = "Orange";
				break;
			}

			case 4:
			{
				cChoice = "Yellow";
				break;
			}

			default:
				return cChoice;
		}

		return cChoice;
	}

	public static String userChoice(){   // This method call gets user input and loops around until the input is valid

		System.out.println("I'm thinking of a color.");
		System.out.println("Is it red, green, blue, orange, or yellow?: ");

		Scanner scnr = new Scanner(System.in);
		String aChoice = scnr.next();
		boolean validChoice;

		do
		{
			validChoice = isValidChoice(aChoice);

			if(validChoice == true)
				break;
			else if (validChoice == false)
			{
				System.out.println("Invalid choice");
				System.out.println("I'm thinking of a color. ");
				System.out.println("Is it red, green, blue, orange, or yellow?: ");
				aChoice = scnr.next();
			}
		}while(validChoice == false);

		return aChoice;

	}
	public static boolean isValidChoice(String aChoice){ // This method call checks if the user input is valid to the colors in the program

		boolean validChoice;

		if(aChoice.equalsIgnoreCase("Red"))
			validChoice = true;
		else if(aChoice.equalsIgnoreCase("Green"))
			validChoice = true;
		else if(aChoice.equalsIgnoreCase("Blue"))
			validChoice = true;
		else if(aChoice.equalsIgnoreCase("Orange"))
			validChoice = true;
		else if(aChoice.equalsIgnoreCase("Yellow"))
			validChoice = true;
		else
			validChoice = false;


		return validChoice;
	}

		public static void main(String[] args){

			int correctCount = 0;
			System.out.println("This program will run 10 times");

			for(int i = 1; i <= 10; i++)    // Since workshop 7 instructions says to run the program 10 times, it is in a for-loop
			{

				String compChoice = computerChoice();
				String getInput = userChoice();

				System.out.println("Computer's Choice: " + compChoice.toUpperCase());
				System.out.println("User's Choice: " + getInput.toUpperCase());

				if(getInput.equalsIgnoreCase(compChoice))
					correctCount++;                              // This integer increments every time the user guesses correctly

				System.out.print("Choice " + i + " was");

					if(getInput.equalsIgnoreCase(compChoice))
						System.out.println(" correct.");

					else
						System.out.println(" incorrect.");


				System.out.println("Number of correct guesses: " + correctCount);
				System.out.println("");
			}}}




				System.out.println("Computer's Choice: " + compChoice.toUpperCase());
				System.out.println("User's Choice: " + getInput.toUpperCase());

				if(getInput.equalsIgnoreCase(compChoice))
					correctCount++;                              // This integer increments every time the user guesses correctly

				System.out.print("Choice " + i + " was");

					if(getInput.equalsIgnoreCase(compChoice))
						System.out.println(" correct.");

					else
						System.out.println(" incorrect.");


				System.out.println("Number of correct guesses: " + correctCount);
				System.out.println("");
			}}}


