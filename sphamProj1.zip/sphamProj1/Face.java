public class Main
{
	public static void main(String[] args) {
		System.out.println("  WWWWWW"); // This hair is very wavy and sticks up
		System.out.println("C| @  @ |D");
		System.out.println(" |   o  | ");
		System.out.println(" |___U__|");
	}
}
