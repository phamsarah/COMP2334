/**
This is the transcript class that includes student's information
and calculates the total average grade point average. 

@author Sarah Pham
@version 1.0

COP2253	Project #: 6
File Name: Transcript.java
*/


public class Transcript {
	
		/**
		 * The student identification number
		 */
	private int studentID;
	
		/**
		 * The student name
		 */
	private String studentName;
	
		/**
		 * The course array
		 */
	private Course [] courses;
	
		/**
		 * The number of total courses
		 */
	private int numberOfCourses;
	
		/**
		 * The constant size of the array courses
		 */
	public final static int SIZE = 10;
	
/**
 * Constructs Transcript with studentID equal to studID ,
 * studentName with studName, and sets the array courses with a size
 * @param studId constructor parameter of the student identification number
 * @param studName constructor parameter of the student whole name
 */
	
	public Transcript(int studId, String studName) {
		
		studentID = studId;
		studentName = studName;
		courses = new Course[SIZE];
		
	}
	
/**
 * Add's the course and grade into the courses array
 * @param courseID the course id being inputed into courses
 * @param letterGrade the grade being inputed into courses 
 */
	
	public void addCourse(String courseID, String letterGrade) {	
		
		Course grade = new Course(courseID, letterGrade);
		
		
		courses[numberOfCourses] = grade; 
		numberOfCourses++;
	}
	
/**
 * Calls calculateGPA and then returns the GPA
 * @return gpa the grade point average of the student
 */
	
	public double getGPA() {
		double gpa = calculateGPA();
		return gpa;
	}
	
/**
 * Private method that calculates the student's GPA 
 * @return sumGrades/numberOfCourses the average of the total numeric value of the grades
 */
	
	private double calculateGPA() {
		
		double sumGrades = 0;
		
		for(int i = 0; i < numberOfCourses; i++) {
			
			sumGrades += courses[i].getNumericGrade();
	
		}
		
		return sumGrades/numberOfCourses;
		
	}
	
/**
 * Prints out all given and calculated information, such as student id, student name, course id, gpa, and grades.
 * @return studentID   the student identification number
 * @return studentName	the student name
 * @return gpaDecimal	the calculated GPA with two decimal places after
 * @return message	the concatenated courses array into a string
 */
	
	public String toString() {
		String message = "";
		for(int i = 0; i < numberOfCourses; i++) {
			message += courses[i].toString() + "\n";
		} 
		

		String gpaDecimal = String.format("%.2f", getGPA());
		
		return("ID: " + studentID + "\n" + 
				   "Name: " + studentName + "\n" + 
				   "GPA: " + gpaDecimal + "\n" + message);
	}
	
	
}

	
	
