/**
 * A class to test the Transcript class.
 * @author Sarah Pham
 * @version 1.0 
 * 
 * COP2253 Project #: 6
 * File Name: TranscriptTester.java
 */


public class TranscriptTester {
	public static void main(String[] args) {
		// Testing A- in COP2253
		
		Transcript John = new Transcript(12345, "John Doe");
		
		System.out.println("Now testing the addCourse method in Transcript with possible valid grades: ");
		
			John.addCourse("COP 2253", "A");
			John.addCourse("COP 3022", "A-");
			John.addCourse("COP 3530", "B");
			John.addCourse("COP 2324" , "B+");
			John.addCourse("COP 6724" , "B-");
			John.addCourse("COP 1224" , "C+");

			
		System.out.println();
		
		System.out.println("Now testing the toString() method in Transcript: ");
		System.out.println();
		
			System.out.println(John.toString());
		
		System.out.println("Now testing the addCourse method with invalid grades: ");
		
			John.addCourse("COP 4321", "A+");
			John.addCourse("COP 3213", "F-");
			John.addCourse("COP 2323", "F+");
			John.addCourse("COP 2333" , "D-");
		
		System.out.println();
		
		System.out.println("Now testing getGPA() and calculateGPA() methods from Transcript: ");
		System.out.println();
		
			System.out.println("GPA: " + John.getGPA());
		

			
	
			
			
	}
	
}
