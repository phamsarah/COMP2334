/**
 * A class used by Transcript to store the course ID and the grade. Also is
 * used to calculate the numeric grade of a letter grade. 
 * 
 * @author Sarah Pham
 * @version 1.0
 * 
 * COP2253 Project #: 6
 * File Name: Course.java
 */
public class Course {
	
		/**
		 * The name of the course
		 */
private String courseID;

		/**
		 * The letter grade of the given course
		 */
private String letterGrade;

		/**
		 * The number grade of the given course
		 */
private double numberGrade;


/**
 * Constructs Course with default values of zero or nothing
 */
	public Course() {
		courseID = "";
		letterGrade = "";
		numberGrade = 0;
	}
	
/**
 * Constructs Course with courseID equal to crsID and letterGrade equal to grade.
 * Also calls computeGrade to calculate the grade.
 * @param crsID	the name of the course
 * @param grade	the grade of the course
 */

	public Course(String crsID, String grade) {
		courseID = crsID;
		letterGrade = grade; 
		
		computeGrade();
	}
	
/**
 * Returns the course ID
 * @return courseID the course ID
 */
	
	public String getCourseID() {
		return courseID;
	}
	
/**
 * Returns the letter grade
 * @return letterGrade the letter grade
 */
	
	public String getLetterGrade() {
		return letterGrade;
	}
	
/**
 * Returns the numberic grade
 * @return numberGrade the number grade
 */
	
	public double getNumericGrade() {
		return numberGrade;
	}
	
	
/**
 * Calculates the numeric grade using the instance variable letterGrade
 * and returns an error if there is an invalid inputed grade
 */
	private void computeGrade() {
		char firstLetter = letterGrade.charAt(0);
		String lastChar = letterGrade.substring(letterGrade.length()-1);
		
		switch(firstLetter) {
		case 'A':
			numberGrade += 4.0;
			break;
		case 'B':
			numberGrade += 3.0;
			break;
		case 'C':
			numberGrade += 2.0;
			break;
		case 'D':
			numberGrade += 1.0;
			break;
		case 'F':
			numberGrade += 0.0;
			break;
		default:
			break;
		}
		
		if(lastChar.equals("+")) {
			if(letterGrade.equalsIgnoreCase("A+"))
			{
				System.out.println("A+ is not a valid grade.");
				return;
			}
			
			else if(letterGrade.equalsIgnoreCase("F+"))
			{
				System.out.println("F+ is not a valid grade.");
				return;
			}
			
			else 
				numberGrade += 0.3;
		}
		
		else if (lastChar.equals("-")) {
			if (letterGrade.equalsIgnoreCase("F-"))
			{
				System.out.println("F- is not a valid grade.");
				return;
			}
			else if(letterGrade.equalsIgnoreCase("D-"))
			{
				System.out.println("D- is not a valid grade.");
				return;
			}
			
			else
				numberGrade -= 0.3;
		}
		
			
	}
	
/**
 * Updates the grade and calls computeGrade to get the numeric value
 * @param newGrade the new grade 
 */
	
	public void updateGrade(String newGrade) {
		letterGrade = newGrade;
		computeGrade();
	}
	
/**
 * returns a concatenated string of the course ID, letter grade, and numeric grade
 * @return getCourseID the method being returned, the result being the course id
 * @return getLetterGrade the method being returned, the result being the letter grade
 * @return getNumericGrade the method being returned, the result being the numeric grade
 */
	
	public String toString() {
		return (getCourseID() + "  " + getLetterGrade() + "   " + getNumericGrade());
	}
	
	
}
