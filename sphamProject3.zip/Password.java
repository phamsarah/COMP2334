/**
This program encrypts and decrypts 
the user password using shifts
on the ascii table. 

@author Sarah Pham
@version 1.0

COP2253    Project 3
File Name: Password.java
*/

import java.util.Scanner;

public class Password {
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Please enter your password: ");
		
		String userPass = scnr.next();
		String encryptedPass = "";
		String decryptedPass = "";
		
		while(userPass.length() < 8) 
		{
			System.out.print("The password must be at least 8 characters long, your password is only " + userPass.length());
			System.out.println(" characters long.");
			System.out.println("Please enter another password: ");
			
			userPass = scnr.next();
		}
		
		System.out.println("Please enter a whole number between 1 and 10(Inclusive) for the encryption key: ");
		int keyNumber = scnr.nextInt();
		
		while(keyNumber < 1 || keyNumber > 10) {
			System.out.println("The key must be between 1 and 10, you entered: " + keyNumber);
			System.out.println("Please enter another whole number between 1 and 10(Inclusive)");
			
			keyNumber = scnr.nextInt();
		}
		
		
		
		for(int i = 0; i < userPass.length(); i++) {
			
			int ascii = userPass.charAt(i);
			int shift = ascii + keyNumber; 
			
			
			if (shift > 122) // Testing if the shift will be more than 122
				shift = 32 + (keyNumber - (122 - ascii));  // The 2 goes into the 120-122 ... therefore is subtracted from the shift
			
			
			char encryptedCharacter = (char) (shift); 
			
			encryptedPass = encryptedPass.concat(Character.toString(encryptedCharacter));
			
		}
			
		System.out.println("Your password is " + userPass + " the encrypted version of your password is " + encryptedPass + " with a key of " + keyNumber);
		
		// Decryption time!
		
		System.out.println("Now time to decrypt, please enter an encrypted password: ");
		String userEncryptPass = scnr.next();
		
		System.out.println("Please enter the key between 1-10 used to generate the password: ");
		int userEncryptKey = scnr.nextInt(); 
		
			while(userEncryptKey < 1 || userEncryptKey > 10)
			{
				System.out.println("Error, please enter the key between 1-10 to generate the password: ");
				userEncryptKey = scnr.nextInt();
			}
		
		
		for(int k = 0; k < userEncryptPass.length(); k++)    // This for loop is the opposite of the previous
		{
			
			int ascii = userEncryptPass.charAt(k);
			int shift = ascii - userEncryptKey;
			
			if(shift < 33)
			{
				System.out.println(shift);
				int a = ascii - 33;						// Taking the shift from the beginning number now instead of 122
				shift = 123 - (userEncryptKey - a);		// 123 because 33 is already counted as a shift count so 122 + 1 or could be 33 + 1
				
				System.out.println(shift);
			}
			
			char decryptedCharacter = (char)(shift);
			
			decryptedPass = decryptedPass.concat(Character.toString(decryptedCharacter));
			
		}
		
		System.out.println(decryptedPass);
		
		
	}

}
