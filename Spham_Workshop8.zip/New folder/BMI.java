import java.util.Scanner;
public class BMI {
	
	static int validNum(int min, int max) {
		Scanner scnr = new Scanner(System.in);
		int value = scnr.nextInt();
		while((value < min) || (value > max)) {
			System.out.println("Enter a number between [" + min + "," + max + "]");
			value = scnr.nextInt();
		}
		
		return value; 
	}
	
	
	public static void main (String[] args) {
		Scanner scnr = new Scanner(System.in);
		
		
		System.out.println("Please enter a body weight to calculate the BMI: ");
		int bodyWeight = validNum(0, 1000);
		
		System.out.println("Please enter a height in inches: ");
		int bodyHeight = validNum(24, 96);
		
		double bmi = bodyWeight * (703 / (Math.pow(bodyHeight, 2)));
		
		if(bmi >= 12 && bmi < 18.5)
			System.out.println("Your BMI shows that you are underweight");
		else if (bmi >= 18.5 && bmi < 24.5)
			System.out.println("Your BMI shows that you are healthy");
		else if (bmi >= 24.5 && bmi < 29.5)
			System.out.println("Your BMI shows that you are overweight");
		else if (bmi >= 29.5 && bmi < 39.5)
			System.out.println("Your BMI shows that you are obese");
		else if (bmi >= 39.5)
			System.out.println("Your BMI shows that you are extremely obese");
		 
		
	}

}
