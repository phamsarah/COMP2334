/**
This program calculates the amount of energy expended
using the concept of metabolic equivalents.
The formula used is
Calories/Minute = 0.0175 * MET * WeightInKilos
One Kg = 2.2 Pounds

@author Sarah Pham
@version 1.0

COP2253    Workshop 3
File Name: Calories.java
*/
import java.util.Scanner;

public class Calories
{
	public static void main(String[] args) {

		// Initializing all constants and variables
		final double RUN_METS = 10;
		final double BBALL_METS = 8;
		final double SLEEP_METS = 1;

        double Weight = 0;

        double run_time = 0;
		double bball_time = 0;
		double sleep_time = 0;

		double runningCalories = 0;
		double bballCalories = 0;
		double sleepCalories = 0;


		String Name;

		Scanner scnr = new Scanner(System.in);

		// System output's each result of calories burned for each activity

		System.out.println("Welcome to the calorie calculator");
		System.out.println("What is your name?");
		Name = scnr.next();

		System.out.println("What is your weight?");
		Weight = scnr.nextDouble();
		double WeightInKilos = Weight / 2.2;

		// USER INPUT

		System.out.println("What are your basketball hours in minutes?");
		bball_time = scnr.nextDouble();

		System.out.println("What are your running hours in minutes?");
		run_time = scnr.nextDouble();

		System.out.println("What are your sleeping hours in minutes?");
		sleep_time = scnr.nextDouble();

		System.out.println("This program will calculate calories burned for " + Name + " who weighs " + Weight + " pounds");

		//Formula is Calories = 0.0175 * METS * WEIGHT * MINS

        runningCalories = 0.0175 * RUN_METS * WeightInKilos * run_time; //Calories burned in running

        System.out.print(Name);
        System.out.printf(" burned an estimated %.2f calories running. \n", runningCalories);

        bballCalories = 0.0175 * BBALL_METS * WeightInKilos * bball_time; // Calories burned in basketball

		System.out.print(Name);
		System.out.printf(" burned an estimated %.2f calories playing basketball \n", bballCalories);

		sleepCalories = 0.0175 * SLEEP_METS * WeightInKilos * sleep_time; // Calories burned in sleeping

		System.out.print(Name);
		System.out.printf(" burned an estimated %.2f calories sleeping \n" , sleepCalories);

		double Expended = runningCalories + bballCalories + sleepCalories; // Calories burned total

		System.out.print(Name);
		System.out.printf(" expended at total of %.2f calories" , Expended);



	}
}
